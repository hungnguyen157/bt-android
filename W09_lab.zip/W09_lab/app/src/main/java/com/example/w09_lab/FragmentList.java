package com.example.w09_lab;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class FragmentList extends Fragment implements FragmentCallBacks{
    // this fragment shows a ListView
    MainActivity main;
    // Context context; // use main or use context

    // items
    TextView txtChosen;
    ListView listView;
    CustomRowAdapter adapter;

    // string to display:
    String message = "";

    // marked previous selected position
    int pre_selected_pos = -1;

    // data to fill-up the ListView
//    private String[] ids = {"19127333", "19127317", "19127456", "19127987", "19127001",
//            "19127029", "19127565", "19127055", "19127548",};
//    private Integer[] avatars = {R.drawable.avatar2, R.drawable.avatar1, R.drawable.avatar3,
//            R.drawable.avatar4, R.drawable.avatar5, R.drawable.avatar2,
//            R.drawable.avatar3, R.drawable.avatar5, R.drawable.avatar4};
    private Integer[] ids;
    private Integer[] avatars;

    // convenient constructor(accept arguments, copy them to a bundle, binds bundle to fragment)
    public static FragmentList newInstance(String strArg) {
        FragmentList fragment = new FragmentList();
        Bundle args = new Bundle();
        args.putString("strArg1", strArg);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        System.out.println("Fragement onCreate");
        super.onCreate(savedInstanceState);
        try {
            main = (MainActivity) getActivity();

            //open database from SQLiteDatabase variable of main
            main.sqliteDb = main.openOrCreateDatabase("W09_lab", main.MODE_PRIVATE, null);

            //get all MaHS and HinhAnh from table HOCSINH
            Cursor cursor = main.sqliteDb.rawQuery("SELECT MaHS, HinhAnh FROM HOCSINH", null);

            //assign MaHS and HinhAnh to array ids and avatars
            cursor.moveToPosition(-1);
            ids = new Integer[cursor.getCount()];
            avatars = new Integer[cursor.getCount()];
            int index = 0;
            while (cursor.moveToNext()){
                ids[index] = (Integer) cursor.getInt(cursor.getColumnIndexOrThrow("MaHS"));
                avatars[index] = (Integer) cursor.getInt(cursor.getColumnIndexOrThrow("HinhAnh"));
                index++;
            }

            //close cursor and database from SQLiteDatabase variable of main
            cursor.close();
            main.sqliteDb.close();
        } catch (IllegalStateException e) {
            throw new IllegalStateException("MainActivity must implement callbacks");
        }
    }

    private void setSelectedItem(int position){
        if (pre_selected_pos != -1){
            listView.getChildAt(pre_selected_pos).setSelected(false);
        }
        listView.getChildAt(position).setSelected(true);
        pre_selected_pos = position;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        System.out.println("Fragment onCreateView");
        // inflate res/layout_list.xml to make GUI holding a TextView and a ListView
        LinearLayout layout_list = (LinearLayout) inflater.inflate(R.layout.layout_list, null);

        // assign first part of sent message
        message = (String) getText(R.string.chosen) + " ";

        // plumbing – get a reference to textview and listview
        txtChosen = (TextView) layout_list.findViewById(R.id.txtChosen);
        txtChosen.setText(message);
        listView = (ListView) layout_list.findViewById(R.id.myListView);

        // define a simple adapter to fill rows of the listview
        adapter = new CustomRowAdapter(main, R.layout.custom_row, ids, avatars);
        listView.setAdapter(adapter);

        // show listview from the top
        listView.setSelection(0);
        listView.smoothScrollToPosition(0);

        // react to click events on listview’s rows
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                // inform enclosing MainActivity of the row’s position just selected
                main.onMsgFromFragToMain("List_Frag",
                                    "MaHS-" + ids[position] + "," + "Position-" + position);
                txtChosen.setText(message + ids[position]);
                setSelectedItem(position);
            }});
        // do this for each row (ViewHolder-Pattern could be used for better performance!)

        return layout_list;
    }

    @Override
    public void onMsgFromMainToFrag (String mess){
        int position = Integer.parseInt(mess);
        txtChosen.setText(message + ids[position]);
        setSelectedItem(position);
        main.onMsgFromFragToMain("List_Frag",
                "MaHS-" + ids[position] + "," + "Position-" + position);
    }
}
