package com.example.w09_lab;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class FragmentDetails extends Fragment implements FragmentCallBacks, View.OnClickListener{
    // this fragment shows a ListView
    MainActivity main;

    // view items
    TextView txtId, txtFullname, txtClass, txtGPA;
    Button btnfirst, btnprevious, btnnext, btnlast;

    // string to display:
    String id, fullname, _class, gpa;
    String idVal, fullnameVal, _classVal, gpaVal;

    // data to fill-up the ListView
//    private String[] ids = {"19127333", "19127317", "19127456", "19127987", "19127001",
//            "19127029", "19127565", "19127055", "19127548"};
//    private String[] names = {"Nguyễn Văn A", "Lê Thị B", "Trần Văn C", "Phan Văn C", "Đinh Văn D",
//            "Nguyễn Tiến Hùng", "Nguyễn Quốc Thông", "Lê Vũ Minh Nhật", "Đặng Công Thành"};
//    private String[] classes = {"19CLC1", "19APCS2", "19APCS3", "19VP4", "19VP1",
//            "19CLC5", "19CLC7", "19CLC7", "19CLC7"};
//    private String[] gpas = {"8", "9", "8.7", "9.56", "9", "10", "10", "10", "10"};

    // position of chosen student and length of list students
    int position = -1, maxpos;

    // convenient constructor(accept arguments, copy them to a bundle, binds bundle to fragment)
    public static FragmentDetails newInstance(String strArg1) {
        FragmentDetails fragment = new FragmentDetails();
        Bundle bundle = new Bundle();
        bundle.putString("arg1", strArg1);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!(getActivity() instanceof MainCallBacks)){
            throw new IllegalStateException("MainActivity must implement callbacks");
        }
        main = (MainActivity) getActivity();

        //open database from SQLiteDatabase variable of main
        main.sqliteDb = main.openOrCreateDatabase("W09_lab", main.MODE_PRIVATE, null);

        //get all MaHS from table HOCSINH
        Cursor cursor = main.sqliteDb.rawQuery("SELECT MaHS, HinhAnh FROM HOCSINH", null);
        maxpos = cursor.getCount() - 1;

        //close cursor and database from SQLiteDatabase variable of main
        cursor.close();
        main.sqliteDb.close();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // inflate res/layout_details.xml which includes textviews and  buttons
        LinearLayout layout_details = (LinearLayout) inflater.inflate(R.layout.layout_details, null);

        id = (String) main.getText(R.string.id) + " ";
        fullname = (String) main.getText(R.string.fullname) + " ";
        _class = (String) main.getText(R.string._class) + " ";
        gpa = (String) main.getText(R.string.gpa) + " ";

        // get all textviews and assign first part of whole string for them
        txtId = (TextView) layout_details.findViewById(R.id.txtId);
        txtId.setText(id);
        txtFullname = (TextView) layout_details.findViewById(R.id.txtFullname);
        txtFullname.setText(fullname);
        txtClass = (TextView) layout_details.findViewById(R.id.txtClass);
        txtClass.setText(_class);
        txtGPA = (TextView) layout_details.findViewById(R.id.txtGPA);
        txtGPA.setText(gpa);

        // get all buttons and set click event listener for them and then disable them
        btnfirst = (Button) layout_details.findViewById(R.id.btnfirst);
        btnfirst.setOnClickListener(this);
        btnfirst.setEnabled(false);
        btnprevious = (Button) layout_details.findViewById(R.id.btnprevious);
        btnprevious.setOnClickListener(this);
        btnprevious.setEnabled(false);
        btnnext = (Button) layout_details.findViewById(R.id.btnnext);
        btnnext.setOnClickListener(this);
        btnnext.setEnabled(false);
        btnlast = (Button) layout_details.findViewById(R.id.btnlast);
        btnlast.setOnClickListener(this);
        btnlast.setEnabled(false);

        // show string argument supplied by constructor (if any!)
        try {
            Bundle arguments = getArguments();
            txtId.setText(arguments.getString("arg1", ""));
        }
        catch (Exception e) {
            Log.e("Detail bunddle error", "" + e.getMessage());
        }

        return layout_details;
    }

    @Override
    public void onMsgFromMainToFrag (String mess){
        String[] mess_components = mess.split(",");
        position = Integer.parseInt(mess_components[0]);
        idVal = mess_components[1];
        fullnameVal = mess_components[2];
        _classVal = mess_components[3];
        gpaVal = mess_components[4];
        setText_checkPosition();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnfirst.getId()){
            position = 0;
        }
        else if (view.getId() == btnprevious.getId()){
            position--;
        }
        else if (view.getId() == btnnext.getId()){
            position++;
        }
        else{
            position = maxpos;
        }
        main.onMsgFromFragToMain("Details_Frag", "Position-" + position);
    }

    private void setText_checkPosition(){
        // setText
        txtId.setText(id + idVal);
        txtFullname.setText(fullname + fullnameVal);
        txtClass.setText(_class + _classVal);
        txtGPA.setText(gpa + gpaVal);

        // check position
        if(position == maxpos){
            btnfirst.setEnabled(true);
            btnprevious.setEnabled(true);
            btnnext.setEnabled(false);
            btnlast.setEnabled(false);
        }
        else if (position == 0){
            btnfirst.setEnabled(false);
            btnprevious.setEnabled(false);
            btnnext.setEnabled(true);
            btnlast.setEnabled(true);
        }
        else{
            btnfirst.setEnabled(true);
            btnprevious.setEnabled(true);
            btnnext.setEnabled(true);
            btnlast.setEnabled(true);
        }
    }
}
