package com.example.w09_lab;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;

public class MainActivity extends FragmentActivity implements MainCallBacks{
    //fragment variables
    FragmentTransaction ft; // only for dynamic binding
    FragmentList fragmentList;
    FragmentDetails fragmentDetails;

    //SQLite Database variable
    SQLiteDatabase sqliteDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("Main onCreate");
        super.onCreate(savedInstanceState);

        //create database if it was deleted from the last time
        if (!this.getDatabasePath("W09_lab").exists()){
            sqliteDb = this.openOrCreateDatabase("W09_lab", MODE_PRIVATE, null);

            //create table LOP and table HOCSINH if the database has been cleared (dropped)
            sqliteDb.execSQL("CREATE TABLE IF NOT EXISTS LOP("
                    + "MaLop integer PRIMARY KEY autoincrement,"
                    + "TenLop string);");
            sqliteDb.execSQL("CREATE TABLE IF NOT EXISTS HOCSINH("
                    + "MaHS integer PRIMARY KEY autoincrement,"
                    + "TenHS string,"
                    + "HinhAnh int,"
                    + "DiemTB float,"
                    + "MaLop integer,"
                    + "FOREIGN KEY(MaLop) REFERENCES LOP(MaLop));");

            //insert data into table LOP
            ContentValues rowValues = new ContentValues();
            rowValues.put("TenLop", "19CLC1");
            sqliteDb.insert("LOP", null, rowValues);
            rowValues.put("TenLop", "19APCS2");
            sqliteDb.insert("LOP", null, rowValues);
            rowValues.put("TenLop", "19APCS3");
            sqliteDb.insert("LOP", null, rowValues);
            rowValues.put("TenLop", "19VP4");
            sqliteDb.insert("LOP", null, rowValues);
            rowValues.put("TenLop", "19VP1");
            sqliteDb.insert("LOP", null, rowValues);
            rowValues.put("TenLop", "19CLC5");
            sqliteDb.insert("LOP", null, rowValues);
            rowValues.put("TenLop", "19CLC7");
            sqliteDb.insert("LOP", null, rowValues);

            //insert data into table HOCSINH
            rowValues.clear();
            rowValues.put("TenHS", "Nguyễn Văn A");
            rowValues.put("HinhAnh", R.drawable.avatar2);
            rowValues.put("DiemTB", 8);
            rowValues.put("MaLop", "1");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Lê Thị B");
            rowValues.put("HinhAnh", R.drawable.avatar1);
            rowValues.put("DiemTB", 9);
            rowValues.put("MaLop", "2");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Trần Văn C");
            rowValues.put("HinhAnh", R.drawable.avatar3);
            rowValues.put("DiemTB", 8.7);
            rowValues.put("MaLop", "3");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Phan Văn C");
            rowValues.put("HinhAnh", R.drawable.avatar4);
            rowValues.put("DiemTB", 9.56);
            rowValues.put("MaLop", "4");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Đinh Văn D");
            rowValues.put("HinhAnh", R.drawable.avatar5);
            rowValues.put("DiemTB", 9);
            rowValues.put("MaLop", "5");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Nguyễn Tiến Hùng");
            rowValues.put("HinhAnh", R.drawable.avatar2);
            rowValues.put("DiemTB", 10);
            rowValues.put("MaLop", "6");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Nguyễn Quốc Thông");
            rowValues.put("HinhAnh", R.drawable.avatar3);
            rowValues.put("DiemTB", 10);
            rowValues.put("MaLop", "7");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Lê Vũ Minh Nhật");
            rowValues.put("HinhAnh", R.drawable.avatar5);
            rowValues.put("DiemTB", 10);
            rowValues.put("MaLop", "7");
            sqliteDb.insert("HOCSINH", null, rowValues);
            rowValues.put("TenHS", "Đặng Công Thành");
            rowValues.put("HinhAnh", R.drawable.avatar4);
            rowValues.put("DiemTB", 10);
            rowValues.put("MaLop", "7");
            sqliteDb.insert("HOCSINH", null, rowValues);

            sqliteDb.close();
            System.out.println("Done close database");
        }

//        if (!this.getDatabasePath("W09_lab").exists()){
//            try{
//                sqliteDb = this.openOrCreateDatabase("W09_lab", MODE_PRIVATE, null);
//
//                //start transaction that make updates to database
//                sqliteDb.beginTransaction();
//                try{
//                    //create table LOP and table HOCSINH
//                    sqliteDb.execSQL("CREATE TABLE IF NOT EXISTS LOP("
//                            + "MaLop integer PRIMARY KEY autoincrement,"
//                            + "TenLop string);");
//                    sqliteDb.execSQL("CREATE TABLE IF NOT EXISTS HOCSINH("
//                            + "MaHS integer PRIMARY KEY autoincrement,"
//                            + "TenHS string,"
//                            + "HinhAnh int,"
//                            + "DiemTB float,"
//                            + "MaLop integer,"
//                            + "FOREIGN KEY(MaLop) REFERENCES LOP(MaLop));");
//
//                    long rowposition;
//                    //insert data into table LOP
//                    ContentValues rowValues = new ContentValues();
//                    rowValues.put("TenLop", "19CLC1");
//                    sqliteDb.insert("LOP", null, rowValues);
//                    rowValues.put("TenLop", "19APCS2");
//                    sqliteDb.insert("LOP", null, rowValues);
//                    rowValues.put("TenLop", "19APCS3");
//                    sqliteDb.insert("LOP", null, rowValues);
//                    rowValues.put("TenLop", "19VP4");
//                    sqliteDb.insert("LOP", null, rowValues);
//                    rowValues.put("TenLop", "19VP1");
//                    sqliteDb.insert("LOP", null, rowValues);
//                    rowValues.put("TenLop", "19CLC5");
//                    sqliteDb.insert("LOP", null, rowValues);
//                    rowValues.put("TenLop", "19CLC7");
//                    sqliteDb.insert("LOP", null, rowValues);
//
//                    //insert data into table HOCSINH
//                    rowValues.clear();
//                    rowValues.put("TenHS", "Nguyễn Văn A");
//                    rowValues.put("HinhAnh", R.drawable.avatar2);
//                    rowValues.put("DiemTB", 8);
//                    rowValues.put("MaLop", "1");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Lê Thị B");
//                    rowValues.put("HinhAnh", R.drawable.avatar1);
//                    rowValues.put("DiemTB", 9);
//                    rowValues.put("MaLop", "2");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Trần Văn C");
//                    rowValues.put("HinhAnh", R.drawable.avatar3);
//                    rowValues.put("DiemTB", 8.7);
//                    rowValues.put("MaLop", "3");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Phan Văn C");
//                    rowValues.put("HinhAnh", R.drawable.avatar4);
//                    rowValues.put("DiemTB", 9.56);
//                    rowValues.put("MaLop", "4");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Đinh Văn D");
//                    rowValues.put("HinhAnh", R.drawable.avatar5);
//                    rowValues.put("DiemTB", 9);
//                    rowValues.put("MaLop", "5");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Nguyễn Tiến Hùng");
//                    rowValues.put("HinhAnh", R.drawable.avatar2);
//                    rowValues.put("DiemTB", 10);
//                    rowValues.put("MaLop", "6");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Nguyễn Quốc Thông");
//                    rowValues.put("HinhAnh", R.drawable.avatar3);
//                    rowValues.put("DiemTB", 10);
//                    rowValues.put("MaLop", "7");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Lê Vũ Minh Nhật");
//                    rowValues.put("HinhAnh", R.drawable.avatar5);
//                    rowValues.put("DiemTB", 10);
//                    rowValues.put("MaLop", "7");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//                    rowValues.put("TenHS", "Đặng Công Thành");
//                    rowValues.put("HinhAnh", R.drawable.avatar4);
//                    rowValues.put("DiemTB", 10);
//                    rowValues.put("MaLop", "7");
//                    sqliteDb.insert("HOCSINH", null, rowValues);
//
//                    //commit all updates to database
//                    sqliteDb.setTransactionSuccessful();
//                }catch (SQLiteException sqliteEx){
//                    sqliteEx.printStackTrace();
//                }finally {
//                    //end the transaction that make updates to database
//                    sqliteDb.endTransaction();
//                }
//                sqliteDb.close();
//                System.out.println("Done close database");
//            }catch (Exception ex){
//                ex.printStackTrace();
//                finish();
//            }
//        }

        System.out.println("Done initialize database");
        setContentView(R.layout.activity_main);

        // only for dynamic binding
//        // create a new list view fragment - show it
//        ft = getSupportFragmentManager().beginTransaction();
//        fragmentList = FragmentList.newInstance("list_student");
//        ft.replace(R.id.list_holder, fragmentList);
//        ft.commit();
//
//        // create a new details view fragment - show it
//        ft = getSupportFragmentManager().beginTransaction();
//        fragmentDetails = FragmentDetails.newInstance("details_student");
//        ft.replace(R.id.details_holder, fragmentDetails);
//        ft.commit();
    }

    // only for static binding
    @Override
    public void onAttachFragment(@NonNull Fragment fragment) {
        super.onAttachFragment(fragment);
        // get a reference to each fragment attached to the GUI
        if (fragment.getClass() == FragmentList.class ){
            fragmentList = (FragmentList) fragment;
        }
        if (fragment.getClass() == FragmentDetails.class ){
            fragmentDetails = (FragmentDetails) fragment;
        }
    }

    @Override
    public void onMsgFromFragToMain (String sender, String mess){
        String MaHS = mess.split("-")[1];
        String position = "" + (Integer.parseInt(MaHS) - 1);
        System.out.println("MaHS: " + MaHS + "\n");
        System.out.println("Position: " + position + "\n");

//        if(sender.equals("List_Frag")){
//            //send message to FragmentDetails
//            sendInfoToFragmentDetails(MaHS, position);
//        }
        if(sender.equals("Details_Frag")){
            fragmentList.onMsgFromMainToFrag(position);
        }
        sendInfoToFragmentDetails(MaHS, position);
    }

    private void sendInfoToFragmentDetails(String MaHS, String position){
        //open database
        sqliteDb = this.openOrCreateDatabase("W09_lab", MODE_PRIVATE, null);

        //get all column from 2 table
        String sql = "SELECT * FROM HOCSINH JOIN LOP ON HOCSINH.MaLop=LOP.MaLop WHERE MaHS=?";

        //create a message which contains MaHS, TenHS, TenLOP and DiemTB of chosen HOCSINH
        String[] args = {MaHS};
        Cursor cursorHS = sqliteDb.rawQuery(sql, args);
        cursorHS.moveToFirst();
        String sent_mess = position + "," + MaHS + ","
                + cursorHS.getString(cursorHS.getColumnIndexOrThrow("TenHS")) + ","
                + cursorHS.getString(cursorHS.getColumnIndexOrThrow("TenLop")) + ","
                + cursorHS.getString(cursorHS.getColumnIndexOrThrow("DiemTB"));

        //close cursor and database
        cursorHS.close();
        sqliteDb.close();

        //send message contains all needed information of chosen HOCSINH to fragmentDetails
        fragmentDetails.onMsgFromMainToFrag(sent_mess);
    }

    @Override
    protected void onDestroy(){
        getApplication().deleteDatabase("W09_lab");
        System.out.println("Goodbye");
        super.onDestroy();
    }
}