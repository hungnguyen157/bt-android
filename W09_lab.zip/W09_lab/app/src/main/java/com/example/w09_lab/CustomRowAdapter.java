package com.example.w09_lab;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomRowAdapter extends ArrayAdapter<Integer> {
    Context context;
    Integer[] ids;
    Integer[] avatars;

    CustomRowAdapter(Context context, int layoutToBeInflated,
                     Integer[] ids, Integer[] avatars){
        super(context, layoutToBeInflated, ids);
        this.context = context;
        this.ids = ids;
        this.avatars = avatars;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        View row = inflater.inflate(R.layout.custom_row, null);
        TextView txtId = (TextView) row.findViewById(R.id.txtId);
        ImageView avatar = (ImageView) row.findViewById(R.id.avatar);

        txtId.setText(ids[position].toString());
        avatar.setImageResource(avatars[position]);

        return (row);
    }
}
