package com.example.w09_lab;

public interface MainCallBacks {
    public void onMsgFromFragToMain (String sender, String mess);
}
