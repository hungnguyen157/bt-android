package com.example.w09_lab;

public interface FragmentCallBacks {
    public void onMsgFromMainToFrag (String mess);
}
